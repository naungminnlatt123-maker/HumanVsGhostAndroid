# Human vs Ghost — Android starter project

## Included
- Android WebView wrapper project for Android Studio.
- Playable offline Friend Mode (Player 1 = blue Human, Player 2 = red Ghost).
- AI mode starter.
- 9x9 connected-node board, keys, exits, stackable Power Charges, turn switching, collision and win conditions.

## Important
This is an Android Studio source project, not a compiled APK. This environment does not include the Android SDK/Gradle build setup, so an APK has not been built here.

## Build an APK
1. Install Android Studio on a computer.
2. Open this project folder (`HumanVsGhostAndroid`) in Android Studio.
3. Let Gradle sync and install the required Android SDK platform (API 35).
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

## Online multiplayer
Online Room is a placeholder and is NOT active yet. To implement real two-device online play:
1. Create a Firebase project.
2. Enable Realtime Database.
3. Add the Firebase web configuration and secure database rules.
4. Implement authenticated room creation/joining and synchronized turn/state validation.
Do not publish a database with public write access. Online mode needs this backend setup; offline Friend and AI modes do not.

## Notes
- This is a starter implementation. Test gameplay thoroughly before distributing.
- The board is a connected 9x9 grid. Special tiles are fixed at the positions encoded in `index.html`.
